<?php

require_once(__DIR__ . '/../config/conexao.php');

class controlaaluno {

    public function inserir($aluno) {
        $sql = "INSERT INTO aluno (nome, email, matricula, curso) VALUES (?, ?, ?, ?)";
        $conn = Conexao::conectar();
        $stmt = $conn->prepare($sql);
        $stmt->execute([$aluno->nome, $aluno->email, $aluno->matricula, $aluno->curso]);
        
    }
                                    
    public function listar() {
        $conn = Conexao::conectar();
        return $conn->query("SELECT * FROM aluno")->fetchAll(PDO::FETCH_ASSOC);
    }

    
    public function buscar($id) {
        $conn = Conexao::conectar();
        $stmt = $conn->prepare("SELECT * FROM aluno WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    
    public function atualizar($aluno) {
    $conn = Conexao::conectar();
    $sql = "UPDATE aluno SET nome=?, email=?, matricula=?, curso=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$aluno->nome, $aluno->email, $aluno->matricula, $aluno->curso, $aluno->id]);
}


   
    public function excluir($id) {
        $conn = Conexao::conectar();
        $stmt = $conn->prepare("DELETE FROM aluno WHERE id = ?");
        $stmt->execute([$id]);
    }
}
?>
