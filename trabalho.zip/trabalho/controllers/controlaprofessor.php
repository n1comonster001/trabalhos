<?php
require_once __DIR__ . '/../config/conexao.php';

class controlaprofessor {
    public function inserir($professor) {
        $conn = Conexao::conectar();
        $sql = "INSERT INTO professor (nome, email, disciplina) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$professor->nome, $professor->email, $professor->disciplina]);
    }

    public function listar() {
        $conn = Conexao::conectar();
        return $conn->query("SELECT * FROM professor")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscar($id) {
        $conn = Conexao::conectar();
        $stmt = $conn->prepare("SELECT * FROM professor WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function atualizar($professor) {
        $conn = Conexao::conectar();
        $sql = "UPDATE professor SET nome=?, email=?, disciplina=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$professor->nome, $professor->email, $professor->disciplina, $professor->id]);
    }

    public function excluir($id) {
        $conn = Conexao::conectar();
        $stmt = $conn->prepare("DELETE FROM professor WHERE id = ?");
        $stmt->execute([$id]);
    }
}
?>
