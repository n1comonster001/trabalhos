<link rel="stylesheet" type="text/css" href="../css/style.css">

<?php
require_once __DIR__ . '/../controllers/controlaprofessor.php';

$ctrl = new controlaprofessor();
$professores = $ctrl->listar();
?>

<div class="container-lista">
    <div class="topo-lista">
        <a href="cadastrar.php" class="botao-azul">Cadastrar Novo Professor</a>
    </div>

    <table border="1">
        <tr><th>ID</th><th>Nome</th><th>Email</th><th>Disciplina</th><th>Ações</th></tr>
        <?php foreach ($professores as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= $p['nome'] ?></td>
            <td><?= $p['email'] ?></td>
            <td><?= $p['disciplina'] ?></td>
            <td>
                <a href="visualizar.php?id=<?= $p['id'] ?>">Ver</a> |
                <a href="editar.php?id=<?= $p['id'] ?>">Editar</a> |
                <a href="excluir.php?id=<?= $p['id'] ?>" onclick="return confirm('Confirmar exclusão?')">Excluir</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
