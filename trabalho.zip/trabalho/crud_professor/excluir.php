<link rel="stylesheet" type="text/css" href="../css/style.css">
<?php
require_once __DIR__ . '/../controllers/controlaprofessor.php';

$ctrl = new controlaprofessor();
$ctrl->excluir($_GET['id']);
header('Location: listar.php');
exit;
?>
