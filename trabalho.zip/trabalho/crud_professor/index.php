<link rel="stylesheet" type="text/css" href="../css/style.css">
<?php
header("Location: listar.php");
exit();
