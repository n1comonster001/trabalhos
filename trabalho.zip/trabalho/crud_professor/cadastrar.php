<link rel="stylesheet" type="text/css" href="../css/style.css">
<?php
require_once __DIR__ . '/../modelos/professor.php';
require_once __DIR__ . '/../controllers/controlaprofessor.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prof = new Professor($_POST['nome'], $_POST['email'], $_POST['disciplina']);
    $ctrl = new controlaprofessor();
    $ctrl->inserir($prof);
    header('Location: listar.php');
    exit;
}
?>

<form method="POST">
    <label>Nome: <input type="text" name="nome" required></label><br>
    <label>Email: <input type="email" name="email" required></label><br>
    <label>Disciplina: <input type="text" name="disciplina" required></label><br>
    <input type="submit" value="Salvar">
</form>
