<link rel="stylesheet" type="text/css" href="../css/style.css">
<?php
require_once __DIR__ . '/../modelos/professor.php';
require_once __DIR__ . '/../controllers/controlaprofessor.php';

$ctrl = new controlaprofessor();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prof = new Professor($_POST['nome'], $_POST['email'], $_POST['disciplina'], $_POST['id']);
    $ctrl->atualizar($prof);
    header('Location: listar.php');
    exit;
}

$professor = $ctrl->buscar($_GET['id']);
?>

<form method="POST">
    <input type="hidden" name="id" value="<?= $professor['id'] ?>">
    <label>Nome: <input type="text" name="nome" value="<?= htmlspecialchars($professor['nome']) ?>" required></label><br>
    <label>Email: <input type="email" name="email" value="<?= htmlspecialchars($professor['email']) ?>" required></label><br>
    <label>Disciplina: <input type="text" name="disciplina" value="<?= htmlspecialchars($professor['disciplina']) ?>" required></label><br>
    <input type="submit" value="Atualizar">
</form>
