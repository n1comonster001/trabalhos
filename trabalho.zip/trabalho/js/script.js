function validarFormulario() {
    const nome = document.getElementById('nome').value;
    if (!nome.trim()) {
        alert("Nome é obrigatório!");
        return false;
    }
    return true;
}