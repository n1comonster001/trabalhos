<?php
class Conexao {
    public static function conectar() {
        return new PDO("pgsql:host=localhost;dbname=crud_escola", "postgres", "postgres");
    }
}

