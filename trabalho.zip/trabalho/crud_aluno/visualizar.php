<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Detalhes do Aluno</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        .form-container {
            display: flex;
            flex-direction: column;
            width: 300px;
            margin: 100px auto;
            gap: 20px;
        }
        .form-container label {
            font-weight: bold;
        }
        .form-container span {
            background: #fff;
            padding: 8px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            display: block;
        }
        .botao-azul {
            background-color: #339af0;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 8px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            display: block;
            width: 100%;
        }
    </style>
</head>
<body>

<?php
require_once __DIR__ . '/../controllers/controlaaluno.php';
$ctrl = new controlaaluno();
$aluno = $ctrl->buscar($_GET['id']);
?>

<div class="form-container">
    <h2>Detalhes do Aluno</h2>

    <label>Nome:</label>
    <span><?= $aluno['nome'] ?></span>

    <label>Email:</label>
    <span><?= $aluno['email'] ?></span>

    <label>Curso:</label>
    <span><?= $aluno['curso'] ?></span>

    <label>Matrícula:</label>
    <span><?= $aluno['matricula'] ?></span>

    <a href="listar.php" class="botao-azul">Voltar</a>
</div>

</body>
</html>
