<?php
header("Location: listar.php");
exit();



