<link rel="stylesheet" type="text/css" href="../css/style.css">
<?php
require_once(__DIR__ . '/../controllers/controlaaluno.php');
require_once(__DIR__ . '/../modelos/aluno.php');

$ctrl = new controlaaluno();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aluno = new Aluno($_POST['nome'], $_POST['email'], $_POST['curso'], $_POST['matricula'], $_POST['id']);
    $ctrl->atualizar($aluno);
    header('Location: listar.php');
    exit;
}

$dados = $ctrl->buscar($_GET['id']);

?>
<form method="POST">
    <input type="hidden" name="id" value="<?= $dados['id'] ?>">
    <label>Nome: <input type="text" name="nome" value="<?= $dados['nome'] ?>"></label><br>
    <label>Email: <input type="email" name="email" value="<?= $dados['email'] ?>"></label><br>
    <label>Curso: <input type="text" name="curso" value="<?= $dados['curso'] ?? '' ?>"></label><br>
    <label>Matrícula: <input type="text" name="matricula" value="<?= $dados['matricula'] ?>"></label><br>
    <input type="submit" value="Atualizar">
</form>





