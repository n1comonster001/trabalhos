<link rel="stylesheet" type="text/css" href="../css/style.css">
<?php
require_once(__DIR__ . '/../controllers/controlaaluno.php');

$ctrl = new controlaaluno();
$ctrl->excluir($_GET['id']);

header('Location: listar.php');
exit;
