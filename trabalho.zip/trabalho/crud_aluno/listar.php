<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">

    <link rel="stylesheet" type="text/css" href="../css/style.css">
<?php
require_once('../controllers/controlaaluno.php');
$ctrl = new controlaaluno();
$alunos = $ctrl->listar();
?>
<div class="container-lista">
    <div class="topo-lista">
    <a href="cadastrar.php" class="botao-azul">Cadastrar Novo Aluno</a>
</div>

    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Curso</th>
            <th>Matrícula</th>
            <th>Ações</th>
        </tr>
        <?php foreach ($alunos as $a): ?>
        <tr>
            <td><?= $a['id'] ?></td>
            <td><?= $a['nome'] ?></td>
            <td><?= $a['email'] ?></td>
            <td><?= $a['curso'] ?></td>
            <td><?= $a['matricula'] ?></td>
            <td>
                <a href="visualizar.php?id=<?= $a['id'] ?>">Ver</a> |
                <a href="editar.php?id=<?= $a['id'] ?>">Editar</a> |
                <a href="excluir.php?id=<?= $a['id'] ?>" onclick="return confirm('Confirmar exclusão?')">Excluir</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

