<link rel="stylesheet" type="text/css" href="../css/style.css">
<?php
require_once('../modelos/aluno.php');
require_once('../controllers/controlaaluno.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_POST['curso'])) { 
        $aluno = new Aluno($_POST['nome'], $_POST['email'], $_POST['curso'], $_POST['matricula']);            
        $ctrl = new controlaaluno();     
        $ctrl->inserir($aluno);          
        header('Location: listar.php');
        exit;
    } else {
        echo "O campo 'curso' é obrigatório!";
    }
}
?>
<form method="POST" onsubmit="return validarFormulario()">
    <label>Nome: <input type="text" name="nome" id="nome"></label><br>
    <label>Email: <input type="email" name="email"></label><br>
    <label>Curso: <input type="text" name="curso"></label><br> 
    <label>Matrícula: <input type="text" name="matricula"></label><br>
    <input type="submit" value="Salvar">
</form>
