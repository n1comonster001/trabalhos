<?php
class Aluno {
    public ?int $id; 
    public string $nome;
    public string $email;
    public string $curso;
    public string $matricula; 

    
    public function __construct(string $nome, string $email, string $curso, string $matricula, ?int $id = null) {
        $this->id = $id; 
        $this->nome = $nome;
        $this->email = $email;
        $this->curso = $curso;
        $this->matricula = $matricula; 
    }

    public function validarEmail(): bool {
        return filter_var($this->email, FILTER_VALIDATE_EMAIL) !== false;
    }

    
    public function getId(): int {
        return $this->id;
    }

    public function getNome(): string {
        return $this->nome;
    }

    public function getEmail(): string {
        return $this->email;
    }

    public function getCurso(): string {
        return $this->curso;
    }

    public function getMatricula(): string {
        return $this->matricula;
    }

    // Métodos para setar valores
    public function setId(int $id): void {
        $this->id = $id;
    }

    public function setNome(string $nome): void {
        $this->nome = $nome;
    }

    public function setEmail(string $email): void {
        $this->email = $email;
    }

    public function setCurso(string $curso): void {
        $this->curso = $curso;
    }

    public function setMatricula(string $matricula): void {
        $this->matricula = $matricula;
    }

    
    public function __toString(): string {
        return "ID: $this->id, Nome: $this->nome, Email: $this->email, Curso: $this->curso, Matrícula: $this->matricula";
    }
}
?>
