<?php
class Professor {
    public $id;
    public $nome;
    public $email;
    public $disciplina;

    public function __construct($nome, $email, $disciplina, $id = null) {
        $this->id = $id;
        $this->nome = $nome;
        $this->email = $email;
        $this->disciplina = $disciplina;
    }
}
?>
