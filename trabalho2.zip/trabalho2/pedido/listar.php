<?php
include_once('../config/config.php');
$conn = conectar();


$query = "
  SELECT p.id,
         c.nome AS cliente,
         p.preco_total,
         p.observacao
    FROM pedidos p
    JOIN cliente c ON p.cliente_id = c.id
   ORDER BY p.id
";

$result = pg_query($conn, $query);

if (!$result) {  
    die("Erro na consulta ao banco: " . pg_last_error($conn));
}

$pedidos = pg_fetch_all($result);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">   
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">      
        <a class="botao" href="cadastrar.php">Cadastrar Novo Pedido</a>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Preço Total</th>
                        <th>Observação</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($pedidos): ?>
                        <?php foreach ($pedidos as $p): ?>
                            <tr>
                                <td><?php echo $p['id']; ?></td>
                                <td><?php echo htmlspecialchars($p['cliente']); ?></td>
                                <td><?php echo htmlspecialchars($p['preco_total']); ?></td>
                                <td><?php echo htmlspecialchars($p['observacao']); ?></td>
                                <td class="action-buttons">
                                    <a class="edit" href="editar.php?id=<?php echo $p['id']; ?>">✏️</a>
                                    <a class="delete" href="excluir.php?id=<?php echo $p['id']; ?>">🗑️</a>
                                    <a class="view-all" href="ver.php?id=<?php echo $p['id']; ?>">👁️</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5">Nenhum pedido encontrado.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
