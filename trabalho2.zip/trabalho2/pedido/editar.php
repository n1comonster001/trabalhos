<?php
include_once('../config/config.php');
$conexao = conectar();

$pedidos = null;

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM pedidos WHERE id = $id";
    $result = pg_query($conexao, $sql);
    if ($result && pg_num_rows($result) > 0) {
        $pedidos = pg_fetch_assoc($result);
    } else {
        echo "Pedido não encontrado.";
        exit;
    }
} else {
    echo "ID do pedido não fornecido.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    
    <style>
        * {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            background-color: #4e4e4e;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: #fff;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            width: 400px;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #2196f3;
            border: none;
            color: #fff;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #1976d2;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 25px;
            background: linear-gradient(to right, #2196f3, #2196f3);
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
            transition: background 0.3s ease;
        }

        .btn-voltar:hover {
            background: linear-gradient(to right, #1976d2, #1976d2);
        }
    </style>
</head>
<body>
    <div class="form-container">
       
        <form action="../pedido/atualizar.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $pedidos['id']; ?>">

            <label for="cliente_id">Cliente:</label>
            <select name="cliente_id" id="cliente_id" required>
                <?php
                $clientes = pg_query($conexao, "SELECT id, nome FROM cliente ORDER BY nome");
                while ($cliente = pg_fetch_assoc($clientes)) {
                    $selected = ($cliente['id'] == $pedidos['cliente_id']) ? 'selected' : '';
                    echo "<option value='{$cliente['id']}' $selected>{$cliente['nome']} (ID: {$cliente['id']})</option>";
                }
                ?>
            </select>

            <label for="preco_total">Preço Total:</label>
            <input type="text" name="preco_total" id="preco_total" value="<?php echo $pedidos['preco_total']; ?>" required>

            <label for="observacao">Observação:</label>
            <input type="text" name="observacao" id="observacao" value="<?php echo $pedidos['observacao']; ?>">

            <input type="submit" value="Atualizar">
            <a href="listar.php" class="btn-voltar">← Voltar à Lista</a>
        </form>
    </div>
</body>
</html>
