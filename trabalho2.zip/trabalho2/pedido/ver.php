<?php
include_once('../config/config.php');

$pedidos = null;

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $conn = conectar();
    $query = "SELECT * FROM pedidos WHERE id = $id";
    $result = pg_query($conn, $query);
    $pedidos = pg_fetch_assoc($result);

    pg_close($conn);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Detalhes do Pedido</title>
    <style>
        body {
            background-color: #2e2e2e;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #fff;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            width: 450px;
            text-align: left;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #111;
        }

        p {
            margin: 10px 0;
            color: #222;
        }

        strong {
            font-weight: bold;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 20px;
            background-color: #2196F3;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .btn-voltar:hover {
            background-color: #1976D2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Detalhes do Pedido</h2>

        <?php if ($pedidos) : ?>
            <p><strong>ID:</strong> <?php echo $pedidos['id']; ?></p>
            <p><strong>ID Cliente:</strong> <?php echo $pedidos['cliente_id']; ?></p>
            <p><strong>Valor Total:</strong>
                R$
                <?php
                    echo is_numeric($pedidos['preco_total'])
                        ? number_format((float)$pedidos['preco_total'], 2, ',', '.')
                        : "Inválido";
                ?>
            </p>
            <p><strong>Observação:</strong> <?php echo $pedidos['observacao']; ?></p>

            <a href="listar.php" class="btn-voltar">← Voltar à Lista</a>
        <?php else : ?>
            <p style="color:red; text-align:center;">Pedido não encontrado.</p>
        <?php endif; ?>
    </div>
</body>
</html>
