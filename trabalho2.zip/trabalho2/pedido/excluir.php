<?php
include_once('../config/config.php');

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $conn = conectar();
    $query = "DELETE FROM pedidos WHERE id = $id";
    $result = pg_query($conn, $query);

    if ($result) {
        $mensagem = "Pedido excluído com sucesso!";
    } else {
        $mensagem = "Erro ao excluir pedido.";
    }

    
    echo "<script>
            alert('$mensagem');
            window.location.href = 'listar.php';
          </script>";
    exit(); 
}
?>
