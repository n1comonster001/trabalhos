<?php
error_reporting(E_ALL & ~E_WARNING);
ini_set('display_errors', 1);
include_once('../config/config.php');

$erroMensagem = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = conectar();
    $cliente_id = pg_escape_string($conn, $_POST['cliente_id']);
    $preco_total = pg_escape_string($conn, $_POST['preco_total']);
    $observacao = pg_escape_string($conn, $_POST['observacao']);

    $query = "INSERT INTO pedidos (cliente_id, preco_total, observacao) 
              VALUES ('$cliente_id', '$preco_total', '$observacao')";
    $result = pg_query($conn, $query);

    if ($result) {
        echo "<script>
                alert('Pedido cadastrado com sucesso!');
                window.location.href = 'listar.php';
              </script>";
        exit;
    } else {
        $erro = pg_last_error($conn);
        if (strpos($erro, 'foreign key constraint') !== false) {
            $erroMensagem = 'Erro: o ID do cliente informado não existe.';
        } else {
            $erroMensagem = 'Erro ao cadastrar pedido: ' . htmlspecialchars($erro);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Pedidos</title>
    <link rel="stylesheet" href="../assets/estilo.css"> 
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #eafdfd, #f3faef);
            margin: 0;
            padding: 20px;
        }

        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
            max-width: 500px;
            margin: 40px auto;
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        label.required::after {
            content: " *";
            color: red;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .botao {
            background: linear-gradient(to right, #2196f3, #1976d2);
            color: white;
            padding: 12px 20px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            text-align: center;
            display: inline-block;
            border: none;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
        }

        .botao:hover {
            background: linear-gradient(to right, #1e88e5, #1565c0);
            transform: scale(1.05);
        }

        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }

        @media (max-width: 600px) {
            .form-actions {
                flex-direction: column;
            }

            .botao {
                width: 100%;
            }
        }

        .btn-submit {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, #2196f3, #2196f3);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            margin-bottom: 10px;
        }

        .btn-submit:hover {
            opacity: 0.9;
        }
        
    </style>
</head>
<body>
    <div class="form-container">
      

        <?php if (!empty($erroMensagem)): ?>
            <div class="error-message"><?php echo $erroMensagem; ?></div>
            <script>
                alert("<?php echo addslashes($erroMensagem); ?>");
            </script>
        <?php endif; ?>

        <form method="POST">
            <label for="cliente_id" class="required">Cliente ID:</label>
            <input type="text" name="cliente_id" id="cliente_id" required>

            <label for="preco_total" class="required">Preço Total:</label>
            <input type="text" name="preco_total" id="preco_total" required>

            <label for="observacao">Observação:</label>
            <input type="text" name="observacao" id="observacao">

            <div class="form-actions">
                <button class="btn-submit" type="submit">Cadastrar</button>
        <button class="btn-submit" type="button" onclick="window.location.href='listar.php'">Voltar à Lista</button>
            </div>
        </form>
    </div>
</body>
</html>
