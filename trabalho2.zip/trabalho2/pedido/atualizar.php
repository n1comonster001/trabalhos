<?php
include_once('../config/config.php');
$conexao = conectar();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = pg_escape_string($conexao, $_POST['id']);
    $cliente_id = pg_escape_string($conexao, $_POST['cliente_id']);
    $preco_total = pg_escape_string($conexao, $_POST['preco_total']);
    $observacao = pg_escape_string($conexao, $_POST['observacao']);

    $sql = "UPDATE pedidos SET 
                cliente_id = '$cliente_id',
                preco_total = '$preco_total',
                observacao = '$observacao'
            WHERE id = '$id'";

    $resultado = pg_query($conexao, $sql);

    if ($resultado) {
        echo "<script>
                alert('Pedido atualizado com sucesso!');
                window.location.href = 'listar.php';
              </script>";
    } else {
        echo "<script>
                alert('Erro ao atualizar o pedido.');
                window.history.back();
              </script>";
    }
} else {
    echo "<script>
            alert('Requisição inválida.');
            window.history.back();
          </script>";
}
?>
