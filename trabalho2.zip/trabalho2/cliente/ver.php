<?php
include_once('../config/config.php');

$cliente = null;

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $conn = conectar();
    $query = "SELECT * FROM cliente WHERE id = $id";
    $result = pg_query($conn, $query);
    $cliente = pg_fetch_assoc($result);

    pg_close($conn);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
   
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg,rgb(92, 92, 92),rgb(92, 92, 92));
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card {
            background-color: #fff;
            border-radius: 15px;
            padding: 30px 40px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            text-align: left;
            max-width: 500px;
            width: 100%;
        }

        .card h2 {
            text-align: center;
            margin-bottom: 25px;
        }

        .card p {
            margin: 10px 0;
            font-size: 16px;
        }

        .card p strong {
            font-weight: bold;
        }

        .btn-voltar {
            display: inline-block;
            margin-top: 25px;
            padding: 10px 25px;
            background: linear-gradient(to right, #2196f3, #2196f3);
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
            transition: background 0.3s ease;
        }

        .btn-voltar:hover {
            background: linear-gradient(to right, #2196f3, #2196f3);
        }
    </style>
</head>
<body>
    <div class="card">
        <?php if ($cliente): ?>
            <p><strong>ID:</strong> <?= htmlspecialchars($cliente['id']) ?></p>
            <p><strong>Nome:</strong> <?= htmlspecialchars($cliente['nome']) ?></p>
            <p><strong>CPF:</strong> <?= htmlspecialchars($cliente['cpf']) ?></p>
            <p><strong>E-mail:</strong> <?= htmlspecialchars($cliente['email']) ?></p>
            <p><strong>Endereço:</strong> <?= htmlspecialchars($cliente['endereco']) ?></p>
            <p><strong>Data de Nascimento:</strong> <?= htmlspecialchars($cliente['data_nasc']) ?></p>
            <p><strong>Telefone:</strong> <?= htmlspecialchars($cliente['telefone']) ?></p>

            <a href="listar.php" class="btn-voltar">← Voltar à Lista</a>
        <?php else: ?>
            <p>Cliente não encontrado.</p>
        <?php endif; ?>
    </div>
</body>
</html>
