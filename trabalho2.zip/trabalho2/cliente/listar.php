<?php
include_once('../config/config.php');
$conn = conectar();


$query = "SELECT id, nome, cpf, email, endereco, data_nasc, telefone FROM cliente ORDER BY id";
$result = pg_query($conn, $query);

if (!$result) {
    die("Erro na consulta ao banco: " . pg_last_error($conn));
}

$clientes = pg_fetch_all($result) ?: [];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
 
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="cliente-page">
    <div class="form-container">
       
        <a class="botao" href="cadastrar.php">Cadastrar Novo Cliente</a>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>E-mail</th>
                        <th>Endereço</th>
                        <th>Data de Nascimento</th>
                        <th>Telefone</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($clientes) > 0): ?>
                        <?php foreach ($clientes as $c): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($c['id']); ?></td>
                                <td><?php echo htmlspecialchars($c['nome']); ?></td>
                                <td><?php echo htmlspecialchars($c['cpf']); ?></td>
                                <td><?php echo htmlspecialchars($c['email']); ?></td>
                                <td><?php echo htmlspecialchars($c['endereco']); ?></td>
                                <td><?php echo htmlspecialchars($c['data_nasc']); ?></td>
                                <td><?php echo htmlspecialchars($c['telefone']); ?></td>
                                <td class="action-buttons">
                                    <a class="edit"    href="editar.php?id=<?php echo urlencode($c['id']); ?>">✏️</a>
                                    <a class="delete"  href="excluir.php?id=<?php echo urlencode($c['id']); ?>">🗑️</a>
                                    <a class="view-all" href="ver.php?id=<?php echo urlencode($c['id']); ?>">👁️</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8">Nenhum cliente encontrado.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
