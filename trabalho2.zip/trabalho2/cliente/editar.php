<?php
include_once('../config/config.php');

if (!isset($_GET['id'])) {
    echo "<script>alert('ID do cliente não fornecido.'); window.location.href='listar.php';</script>";
    exit;
}

$conn = conectar();
$id = pg_escape_string($conn, $_GET['id']);
$query = "SELECT * FROM cliente WHERE id = $id";
$result = pg_query($conn, $query);
$cliente = pg_fetch_assoc($result);

if (!$cliente) {
    echo "<script>alert('Cliente não encontrado.'); window.location.href='listar.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Cliente</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .btn-voltar {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 16px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .btn-voltar:hover {
            background-color: #007bff;          
        }

    .btn-submit {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, #2196f3, #2196f3);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            margin-bottom: 10px;
        }

        .btn-submit:hover {
            opacity: 0.9;
        }
        
    </style>
</head>
<body class="cliente-page sem-borda">

    <div class="form-container">
     
        <form action="atualizar.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $cliente['id']; ?>">

            <label for="nome">Nome:</label>
            <input type="text" name="nome" value="<?php echo $cliente['nome']; ?>" required>

            <label for="cpf">CPF:</label>
            <input type="text" name="cpf" value="<?php echo $cliente['cpf']; ?>" required>

            <label for="email">E-mail:</label>
            <input type="email" name="email" value="<?php echo $cliente['email']; ?>" required>

            <label for="endereco">Endereço:</label>
            <input type="text" name="endereco" value="<?php echo $cliente['endereco']; ?>" required>

            <label for="data_nasc">Data de Nascimento:</label>
            <input type="date" name="data_nasc" value="<?php echo $cliente['data_nasc']; ?>" required>

            <label for="telefone">Telefone:</label>
            <input type="text" name="telefone" value="<?php echo $cliente['telefone']; ?>" required>

            <button class="btn-submit" type="submit">Atualizar</button>
        <button class="btn-submit" type="button" onclick="window.location.href='listar.php'">Voltar à Lista</button>
        </form>
    </div>
</body>
</html>
