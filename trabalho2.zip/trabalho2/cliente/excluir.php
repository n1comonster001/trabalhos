<?php
include_once('../config/config.php');

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];


    $conn = conectar();


    $query_check = "SELECT * FROM cliente WHERE id = $id";
    $result_check = pg_query($conn, $query_check);

    if (pg_num_rows($result_check) > 0) {
  
        $query = "DELETE FROM cliente WHERE id = $id";
        $result = pg_query($conn, $query);

        if ($result) {
       
            echo "<script>
                    alert('Cliente excluído com sucesso!');
                    window.location.href = 'listar.php'; // Redireciona para a página listar.php
                  </script>";
        } else {
          
            echo "<script>
                    alert('Não é possível excluir o cliente enquanto houver pedidos vinculados a ele, pois um pedido não pode existir de forma independente, sem estar associado a um cliente. Para prosseguir com a exclusão, é necessário remover previamente todos os pedidos relacionados.');
                    window.location.href = 'listar.php'; // Redireciona para a página listar.php
                  </script>";
        }
    } else {
      
        echo "<script>
                alert('Cliente não encontrado.');
                window.location.href = 'listar.php';
              </script>";
    }
}
?>
