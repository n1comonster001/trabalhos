<?php
include_once('../config/config.php');
$conn = conectar();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = pg_escape_string($conn, $_POST['id']);
    $nome = pg_escape_string($conn, $_POST['nome']);
    $cpf = pg_escape_string($conn, $_POST['cpf']);
    $email = pg_escape_string($conn, $_POST['email']);
    $endereco = pg_escape_string($conn, $_POST['endereco']);
    $data_nasc = pg_escape_string($conn, $_POST['data_nasc']);
    $telefone = pg_escape_string($conn, $_POST['telefone']);

    $query = "UPDATE cliente 
              SET nome='$nome', cpf='$cpf', email='$email', endereco='$endereco', data_nasc='$data_nasc', telefone='$telefone' 
              WHERE id=$id";
    $result = pg_query($conn, $query);

    if ($result) {
        echo "<script>
                alert('Cliente atualizado com sucesso!');
                window.location.href = 'listar.php';
              </script>";
    } else {
        echo "<script>alert('Erro ao atualizar cliente.');</script>";
    }
}
?>
