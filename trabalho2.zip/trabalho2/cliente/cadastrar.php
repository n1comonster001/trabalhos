<?php
include_once('../config/config.php');

$sucesso = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = conectar();
    $nome = pg_escape_string($conn, $_POST['nome']);
    $cpf = pg_escape_string($conn, $_POST['cpf']);
    $email = pg_escape_string($conn, $_POST['email']);
    $endereco = pg_escape_string($conn, $_POST['endereco']);
    $data_nasc = pg_escape_string($conn, $_POST['data_nasc']);
    $telefone = pg_escape_string($conn, $_POST['telefone']);

    $query = "INSERT INTO cliente (nome, cpf, email, endereco, data_nasc, telefone) 
              VALUES ('$nome', '$cpf', '$email', '$endereco', '$data_nasc', '$telefone')";
    $result = pg_query($conn, $query);

    if ($result) {
        $sucesso = true;
    } else {
        echo "<script>alert('Erro ao cadastrar cliente.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
  
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .btn-voltar {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 16px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .btn-voltar:hover {
            background-color: #0056b3;
        }

        .btn-submit {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, #2196f3, #2196f3);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            margin-bottom: 10px;
        }

        .btn-submit:hover {
            opacity: 0.9;
        }
        
    </style>
</head>
<body class="cliente-page sem-borda">
    
    <div class="form-container">
        
        
        <form method="POST">
            <label for="nome">Nome: <span style="color:red">*</span></label>
            <input type="text" name="nome" required>

            <label for="cpf">CPF: <span style="color:red">*</span></label>
            <input type="text" name="cpf" required>

            <label for="email">E-mail: <span style="color:red">*</span></label>
            <input type="email" name="email" required>

            <label for="endereco">Endereço: <span style="color:red">*</span></label>
            <input type="text" name="endereco" required>

            <label for="data_nasc">Data de Nascimento: <span style="color:red">*</span></label>
            <input type="date" name="data_nasc" required>

            <label for="telefone">Telefone: <span style="color:red">*</span></label>
            <input type="text" name="telefone" required>

            <button class="btn-submit" type="submit">Cadastrar</button>
        <button class="btn-submit" type="button" onclick="window.location.href='listar.php'">Voltar à Lista</button>
        </form>
    </div>

    <?php if ($sucesso): ?>
        <script>
            alert("Cliente cadastrado com sucesso!");
            window.location.href = "listar.php";
        </script>
    <?php endif; ?>


</body>
</html>
