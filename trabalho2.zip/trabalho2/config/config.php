<?php

function conectar() {
    
    $host = 'localhost';       
    $port = '5432';            
    $dbname = 'localhost'; 
    $user = 'postgres';     
    $password = 'postgres';   

    $conn = pg_connect("host=localhost port=5432 dbname=loja_online user=postgres password=postgres");

    if (!$conn) {
   
        die("Erro na conexão com o banco de dados: " . pg_last_error());
    }
    return $conn;
}
?>
