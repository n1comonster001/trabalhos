<?php
echo "<!DOCTYPE html>";
echo "<html lang='pt-BR'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<link rel='stylesheet' href='css/style.css'>";
echo "</head>";
echo "<body>";
echo "<div class='box'>";
echo "<ul class='menu-links'>";
echo "<li><a href='cliente/listar.php'>Clientes</a></li>";
echo "<li><a href='produto/listar.php'>Produtos</a></li>";
echo "<li><a href='pedido/listar.php'>Pedidos</a></li>";
echo "</ul>";
echo "</div>";
echo "</body>";
echo "</html>";
?>
