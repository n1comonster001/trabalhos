<?php
include_once('../config/config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conexao = conectar();
    $nome = pg_escape_string($conexao, $_POST['nome']);
    $preco = pg_escape_string($conexao, $_POST['preco']);
    $qtd_estoque = pg_escape_string($conexao, $_POST['qtd_estoque']);

    $query = "INSERT INTO produto (nome, preco, qtd_estoque) VALUES ('$nome', '$preco', '$qtd_estoque')";
    $result = pg_query($conexao, $query);

    if ($result) {
        echo "<script>
                alert('Produto cadastrado com sucesso!');
                window.location.href = 'listar.php';
              </script>";
        exit();
    } else {
        echo "<script>alert('Erro ao cadastrar produto.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    
    <style>
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, rgb(54, 54, 54), rgb(53, 54, 54));
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            width: 400px;
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #444;
            font-weight: bold;
        }

        .form-group label.required::after {
            content: " *";
            color: red;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 10px;
            outline: none;
            transition: 0.3s;
        }

        .form-group input:focus {
            border-color: #2196f3;
        }

        .btn-submit {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, #2196f3, #2196f3);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            margin-bottom: 10px;
        }

        .btn-submit:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<div class="form-container">
   
    <form method="POST">
        <div class="form-group">
            <label class="required">Nome:</label>
            <input type="text" name="nome" required>
        </div>

        <div class="form-group">
            <label class="required">Preço:</label>
            <input type="text" name="preco" required>
        </div>

        <div class="form-group">
            <label class="required">Quantidade em Estoque:</label>
            <input type="text" name="qtd_estoque" required>
        </div>

        <button class="btn-submit" type="submit">Cadastrar</button>
        <button class="btn-submit" type="button" onclick="window.location.href='listar.php'">Voltar à Lista</button>
    </form>
</div>

</body>
</html>
