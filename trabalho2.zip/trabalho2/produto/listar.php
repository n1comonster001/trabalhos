<?php
include_once('../config/config.php');
$conn = conectar();


$query = "SELECT * FROM produto ORDER BY idproduto";
$result = pg_query($conn, $query);

if (!$result) {
    die("Erro na consulta ao banco: " . pg_last_error($conn));
}


$produtos = pg_fetch_all($result) ?: [];


pg_result_seek($result, 0);
$first = pg_fetch_assoc($result) ?: [];
$colunas = array_keys($first);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
  
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        
        <a class="botao" href="cadastrar.php">Cadastrar Novo Produto</a>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <?php foreach ($colunas as $col): ?>
                            <th><?php echo htmlspecialchars($col); ?></th>
                        <?php endforeach; ?>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($produtos) > 0): ?>
                        <?php foreach ($produtos as $p): ?>
                            <tr>
                                <?php foreach ($colunas as $col): ?>
                                    <td><?php echo htmlspecialchars($p[$col]); ?></td>
                                <?php endforeach; ?>
                                <td class="action-buttons">
                                    <a class="edit"    href="editar.php?id=<?php echo urlencode($p[$colunas[0]]); ?>">✏️</a>
                                    <a class="delete"  href="excluir.php?id=<?php echo urlencode($p[$colunas[0]]); ?>">🗑️</a>
                                    <a class="view-all" href="ver.php?id=<?php echo urlencode($p[$colunas[0]]); ?>">👁️</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="<?php echo count($colunas) + 1; ?>">
                                Nenhum produto encontrado.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
