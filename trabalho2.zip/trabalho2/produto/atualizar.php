<?php
include_once('../config/config.php');
$conexao = conectar();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];  
    $Quantidadeemestoque = $_POST['qtd_estoque'];
    $nome = $_POST['nome'];
    $preco = $_POST['preco'];

    $sql = "UPDATE cliente SET nome = '$nome', preco = '$preco', qtd_estoque = '$Quantidadeemestoque' WHERE id = $id";

    if (pg_query($conexao, $sql)) {
        
        echo "<script>
                alert('Cliente atualizado com sucesso!');
                window.location.href = 'listar.php'; // Redireciona para a página de listagem
              </script>";
        exit(); 
    } else {
       
        echo "<script>
                alert('Erro ao atualizar o cliente.');
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Atualizar Cliente</title>
</head>
<body>


<form method="POST">
    <input type="hidden" name="id" value="<?= isset($cliente['id']) ? $cliente['id'] : ''; ?>">
    <div>
        <label for="nome">Nome:</label>
        <input type="text" name="nome" value="<?= isset($cliente['nome']) ? $cliente['nome'] : ''; ?>" required>
    </div>

    <div>
        <label for="preco">Preço:</label>
        <input type="text" name="preco" value="<?= isset($cliente['preco']) ? $cliente['preco'] : ''; ?>" required>
    </div>

    <div>
        <label for="qtd_estoque">Quantidade em Estoque:</label>
        <input type="text" name="qtd_estoque" value="<?= isset($cliente['qtd_estoque']) ? $cliente['qtd_estoque'] : ''; ?>" required>
    </div>

    <button type="submit">Atualizar</button>
</form>

</body>
</html>
