<?php
include_once('../config/config.php');

$produtos = null;

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $conn = conectar();
    $query = "SELECT * FROM produto WHERE idproduto = $id";
    $result = pg_query($conn, $query);
    $produtos = pg_fetch_assoc($result);

    pg_close($conn);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
  
    <style>
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg,rgb(92, 92, 92),rgb(92, 92, 92));
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            width: 400px;
        }

        .container h1 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        .detalhes p {
            margin: 10px 0;
            color: #444;
            font-size: 16px;
        }

        .botao {
            display: block;
            text-align: center;
            margin-top: 20px;
            background: linear-gradient(to right, #2196f3, #2196f3);
            color: white;
            padding: 10px;
            border-radius: 10px;
            text-decoration: none;
            transition: 0.3s;
        }

        .botao:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="container">
     

        <?php if ($produtos) : ?>
            <div class="detalhes">
                <p><strong>ID:</strong> <?php echo $produtos['idproduto']; ?></p>
                <p><strong>Nome:</strong> <?php echo $produtos['nome']; ?></p>
                <p><strong>Preço:</strong> R$ <?php echo number_format($produtos['preco'], 2, ',', '.'); ?></p>
                <p><strong>Quantidade em Estoque:</strong> <?php echo $produtos['qtd_estoque']; ?></p>
            </div>
            <a href="listar.php" class="botao">← Voltar à Lista</a>
        <?php else : ?>
            <p style="text-align:center; color: #fff;">Produto não encontrado.</p>
        <?php endif; ?>
    </div>
</body>
</html>
