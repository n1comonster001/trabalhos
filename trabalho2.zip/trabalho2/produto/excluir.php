<?php
include_once('../config/config.php');

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $conn = conectar();
    $query = "DELETE FROM produto WHERE idproduto = $id";
    $result = pg_query($conn, $query);

    if ($result) {
       
        echo "<script>
                alert('Produto excluído com sucesso!');
                window.location.href = 'listar.php'; // Redireciona para a página de listagem
              </script>";
    } else {
      
        echo "<script>
                alert('Erro ao excluir produto.');
                window.location.href = 'listar.php'; // Redireciona em caso de erro também
              </script>";
    }
}
?>
